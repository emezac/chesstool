Downloading Cheetah
===================

You can download wheels, eggs and tarballs of Cheetah from the `Python
Package Index <http://pypi.org/project/Cheetah3/>`_.

You can keep up to date with release candidates or other downloads of
Cheetah by visiting the `CheetahTemplate GitHub page
<http://github.com/CheetahTemplate3/cheetah3>`_

**Note to Windows users:** You should install the compiled version of
Cheetah's NameMapper. It is dramatically faster than the pure Python
version. Installing from wheels from PyPI is the simplest way to get the
precompiled NameMapper extension.
