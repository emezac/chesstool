Cheetah\.NameMapper module
==========================

.. automodule:: Cheetah.NameMapper
    :members:
    :undoc-members:
    :show-inheritance:
