Cheetah\.Tests\.NameMapper\_pure module
=======================================

.. automodule:: Cheetah.Tests.NameMapper_pure
    :members:
    :undoc-members:
    :show-inheritance:
