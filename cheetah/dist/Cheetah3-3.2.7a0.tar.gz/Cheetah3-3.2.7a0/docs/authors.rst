Authors and contributors
========================

Cheetah was originally written by Tavis Rudd <tavis at damnsimple.com>.

Contributions have been made by:

* Mike Orr <sluggoster at gmail.com>
* Chuck Esterbrook <echuck at mindspring.com>
* Shannon JJ Behrens <jjinux at gmail.com>
* Ian Bicking <ian at ianbicking.org>
* \R. Tyler Croy <tyler at monkeypox.org>
* James Abbatiello <abbeyj at gmail.com>
* Jean-Baptiste Quenot <jbq at caraldi.com>
* Marc Abramowitz <marc at marc-abramowitz.com>
* Mike Bonnet <mikeb at redhat.com>
* Doug Knight <karmix0 at gmail.com>
* Jon Siddle <js at corefiling.co.uk>
* Anwesha Das <anwesha at das.community>
* Arun Kumar <arunkakorp at gmail.com>
* Austin Haigh <austin at haigh.com>
* Darren Yin <darren.yin at gmail.com>
* Evan Klitzke <evan at yelp.com>
* Kurt Schwehr <schwehr at google.com>
* Lakshmi Vyasarajan <lakshmi.vyas at gmail.com>
* Mika Eloranta <mel at ohmu.fi>
* mikola <mikola at tut.by>
* Adam Karpierz <python at python.pl>
* Jonathan Ross Rogers <jrogers at emphasys-software.com>
* Dale Sedivec <dsedivec at emphasys-software.com>
* Mathias Stearn <redbeard0531 at gmail.com>
* Nicola Soranzo <nicola.soranzo at gmail.com>
* Pierre-Yves <pyu at riseup.net>
* Dan Vinakovsky <dvinak at gmail.com>
* Yegor Yefremov <yegorslists at googlemail.com>
* Andrew J. Hesford <ajh at sideband.org>
* Oleg Broytman <phd@phdru.name>
